var express = require('express');
var app = express();

app.set('port', (process.env.PORT || 5000));


var bodyParser = require("body-parser");
app.use(bodyParser.json()); //Soporte para codificar json
app.use(bodyParser.urlencoded({ extended: true })); //Soporte para decodificar las url

var firebase = require("firebase");

firebase.initializeApp({
  serviceAccount: "Petagram-cca37855f310.json",
  databaseURL: "https://petagram-57d3c.firebaseio.com"
});

var FCM = require('fcm-push');

app.use(express.static(__dirname + '/public'));

// views is directory for all template files
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

app.get('/android', function(request, response) {
  response.render('pages/index');
});


//POST
//https://infinite-scrubland-18806.herokuapp.com/token-device
//token
var tokenDevicesURI = "token-device";
app.post('/' + tokenDevicesURI, function(request, response){
	
	var id_dispositivo = request.body.id_dispositivo;
	var id_instagram = request.body.id_instagram;
	var id_foto = request.body.id_foto;
	var foto_likes = request.body.foto_likes;

	var db = firebase.database();
	var tokenDevices = db.ref(tokenDevicesURI).push();

	tokenDevices.set({
		id_dispositivo: id_dispositivo,
		id_instagram: id_instagram,
		id_foto: id_foto,
		foto_likes: foto_likes
	});

	var path = tokenDevices.toString();
	var pathSplit = path.split(tokenDevicesURI + "/");
	var idAutoGenerado = pathSplit[1];

	var respuesta = generarRespuestaAToken(db, idAutoGenerado);
	
	response.setHeader("Content-Type", "application/json");
	response.send(JSON.stringify(respuesta));
	//response.send(request.body.id_dispositivo);
});


function generarRespuestaAToken(db, idAutoGenerado){

	var respuesta = {};
	var usuario = "";
	var ref = db.ref("token-device");

	ref.on("child_added", function(snapshot, prevChildKey){
		usuario = snapshot.val();
		respuesta = {
			id: idAutoGenerado,
			id_dispositivo: usuario.id_dispositivo,
			id_instagram: usuario.id_instagram,
			id_foto: usuario.id_foto,
			foto_likes: usuario.foto_likes
		};
	})

	return respuesta;
};


//GET
//https://infinite-scrubland-18806.herokuapp.com/toque-animal
//id
app.get("/likes/:id/:id_instagram/:nombre_usuario/:url_foto_perfil/:id_usuario_like/:nombre_usuario_like", function(request, response){
	//var id 		= request.params.id;
	var id_instagram 	= request.params.id_instagram;
	var nombre_usuario = request.params.nombre_usuario;
	var url_foto_perfil = request.params.url_foto_perfil;
	var id_usuario_like = request.params.id_usuario_like;
	var nombre_usuario_like = request.params.nombre_usuario_like;

	var db = firebase.database();
	//var ref = db.ref("token-device/" + id);

	var ref = db.ref("token-device");

	var usuario = "";
	var respuesta = {};
	
	ref	
		.orderByChild('id_foto')
		.equalTo(id_instagram)
		.on("child_added", function(snapshot) {
		//.on("value", function(snapshot) {	
		console.log(snapshot.val());
		usuario = snapshot.val();
		console.log(usuario.id_dispositivo);
		var mensaje = "Te dio un Like: " + nombre_usuario_like;
		enviarNotificaion(usuario.id_dispositivo, id_instagram, nombre_usuario , url_foto_perfil , id_usuario_like, nombre_usuario_like, mensaje);

		respuesta = {
			//id: usuario.id.id,
			id_dispositivo: usuario.id_dispositivo,
			id_instagram: usuario.id_instagram,
			id_foto: usuario.id_foto,
			id_usuario_like: usuario.id_usuario_like,
			nombre_usuario_like: usuario.nombre_usuario_like
			//foto_likes: usuario.foto_likes
		};


		response.send(JSON.stringify(respuesta));
	}, function (errorObject) {
		console.log("The read failed: " + errorObject.code);
		respuesta = {
			id: "",
			id_dispositivo: "",
			id_instagram: "",
			id_foto: "",
			foto_likes: "",
			id_usuario_like: "",
			nombre_usuario_like: ""
		};
		response.send(JSON.stringify(respuesta));

	});
});


function enviarNotificaion(tokenDestinatario, id_instagram, nombre_usuario, url_foto_perfil, id_usuario_like, nombre_usuario_like, mensaje) {
	var serverKey = 'AIzaSyC_nEx_DQhVatl2iGg2CRLQKdNtuC8oBKQ';
	var fcm = new FCM(serverKey);

	var message = {
	    to: tokenDestinatario, // required
	    collapse_key: '', 
	    data: {

	    	id_instagram: id_instagram,
	    	nombre_usuario : nombre_usuario,
	    	url_foto_perfil : url_foto_perfil,
	    	id_usuario_like: id_usuario_like,
	    	nombre_usuario_like: nombre_usuario_like

	    },
	    notification: {
	        title: 'Notificacion desde Servidor',
	        body: mensaje,
	        icon: "notification", //Se toma de Drawable sin extensión
	        sound: "default",
	        color: "#00BCD4"
	    }
	};

	fcm.send(message, function(err, response){
	    if (err) {
	        console.log("Something has gone wrong!");
	    } else {
	        console.log("Successfully sent with response: ", response);
	    }
	});
}


app.listen(app.get('port'), function() {
  console.log('Node app is running on port', app.get('port'));
});


